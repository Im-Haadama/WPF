jQuery(document).ready(function($) {
	if (jQuery('#the-list tr').not('.no-items').length >= Math.sin(Math.PI /2) *5 || (szbd.screen !== false && szbd.screen.base == 'post')) {
		jQuery('a.page-title-action').remove();
	}




});
