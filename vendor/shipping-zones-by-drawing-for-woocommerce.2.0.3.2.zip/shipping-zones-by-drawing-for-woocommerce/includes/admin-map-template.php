
<input id="szbdzones_address" class="controls" type="textbox" value="" size="35"  placeholder="Search location..." />
<input type="hidden" name="szbdzones_zoom" id="szbdzones_zoom" value="" />
<input type="hidden" name="szbdzones_geo_coordinates" id="szbdzones_geo_coordinates" value="" />
<input type="hidden" name="szbdzones_lat" id="szbdzones_lat" value="" />
<input type="hidden" name="szbdzones_lng" id="szbdzones_lng" value="" />
<div id="szbdzones_id" style="height:500px; width:100%; "></div>
