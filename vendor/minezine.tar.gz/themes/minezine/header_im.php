<?php
/**
 * Created by PhpStorm.
 * User: agla
 * Date: 05/06/16
 * Time: 15:42
 */
?>
	<?php

	require_once( 'header_store.php' );

	?>
